1. unzip udpconfig.zip to any directory.
2. run udpconfig.exe, it will bind UDP to port 23455.											
3. power on the charger with ethernet connected to the same LAN.
4. When the charger get IP via DHCP, it will broadcast configuration to address XXX.XXX.XXX.255.
5. Then the configuration tool can get the message, you can edit it and send the new configuration to the chager.
6. When the charger get the new configuration, it will restart to apply it.


